package com.example.kennethgame

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
