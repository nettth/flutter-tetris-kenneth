import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(const TetrisApp());
}

// ============================================================
// APP
// ============================================================

class TetrisApp extends StatelessWidget {
  const TetrisApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Tetris',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF050711),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

// ============================================================
// CONSTANTS
// ============================================================

const int boardWidth = 10;
const int boardHeight = 20;

const List<Color> pieceColors = [
  Color(0xFF29D9FF), // I
  Color(0xFFFFD83D), // O
  Color(0xFFB46CFF), // T
  Color(0xFF42E878), // S
  Color(0xFFFF5267), // Z
  Color(0xFF4D8DFF), // J
  Color(0xFFFFA13D), // L
];

// ============================================================
// CELL
// ============================================================

class Cell {
  final int x;
  final int y;

  const Cell(this.x, this.y);
}

// ============================================================
// SHAPES
// ============================================================

const List<List<List<Cell>>> shapes = [
  // I
  [
    [
      Cell(0, 1),
      Cell(1, 1),
      Cell(2, 1),
      Cell(3, 1),
    ],
    [
      Cell(2, 0),
      Cell(2, 1),
      Cell(2, 2),
      Cell(2, 3),
    ],
    [
      Cell(0, 2),
      Cell(1, 2),
      Cell(2, 2),
      Cell(3, 2),
    ],
    [
      Cell(1, 0),
      Cell(1, 1),
      Cell(1, 2),
      Cell(1, 3),
    ],
  ],

  // O
  [
    [
      Cell(1, 0),
      Cell(2, 0),
      Cell(1, 1),
      Cell(2, 1),
    ],
    [
      Cell(1, 0),
      Cell(2, 0),
      Cell(1, 1),
      Cell(2, 1),
    ],
    [
      Cell(1, 0),
      Cell(2, 0),
      Cell(1, 1),
      Cell(2, 1),
    ],
    [
      Cell(1, 0),
      Cell(2, 0),
      Cell(1, 1),
      Cell(2, 1),
    ],
  ],

  // T
  [
    [
      Cell(1, 0),
      Cell(0, 1),
      Cell(1, 1),
      Cell(2, 1),
    ],
    [
      Cell(1, 0),
      Cell(1, 1),
      Cell(2, 1),
      Cell(1, 2),
    ],
    [
      Cell(0, 1),
      Cell(1, 1),
      Cell(2, 1),
      Cell(1, 2),
    ],
    [
      Cell(1, 0),
      Cell(0, 1),
      Cell(1, 1),
      Cell(1, 2),
    ],
  ],

  // S
  [
    [
      Cell(1, 0),
      Cell(2, 0),
      Cell(0, 1),
      Cell(1, 1),
    ],
    [
      Cell(1, 0),
      Cell(1, 1),
      Cell(2, 1),
      Cell(2, 2),
    ],
    [
      Cell(1, 1),
      Cell(2, 1),
      Cell(0, 2),
      Cell(1, 2),
    ],
    [
      Cell(0, 0),
      Cell(0, 1),
      Cell(1, 1),
      Cell(1, 2),
    ],
  ],

  // Z
  [
    [
      Cell(0, 0),
      Cell(1, 0),
      Cell(1, 1),
      Cell(2, 1),
    ],
    [
      Cell(2, 0),
      Cell(1, 1),
      Cell(2, 1),
      Cell(1, 2),
    ],
    [
      Cell(0, 1),
      Cell(1, 1),
      Cell(1, 2),
      Cell(2, 2),
    ],
    [
      Cell(1, 0),
      Cell(0, 1),
      Cell(1, 1),
      Cell(0, 2),
    ],
  ],

  // J
  [
    [
      Cell(0, 0),
      Cell(0, 1),
      Cell(1, 1),
      Cell(2, 1),
    ],
    [
      Cell(1, 0),
      Cell(2, 0),
      Cell(1, 1),
      Cell(1, 2),
    ],
    [
      Cell(0, 1),
      Cell(1, 1),
      Cell(2, 1),
      Cell(2, 2),
    ],
    [
      Cell(1, 0),
      Cell(1, 1),
      Cell(0, 2),
      Cell(1, 2),
    ],
  ],

  // L
  [
    [
      Cell(2, 0),
      Cell(0, 1),
      Cell(1, 1),
      Cell(2, 1),
    ],
    [
      Cell(1, 0),
      Cell(1, 1),
      Cell(1, 2),
      Cell(2, 2),
    ],
    [
      Cell(0, 1),
      Cell(1, 1),
      Cell(2, 1),
      Cell(0, 2),
    ],
    [
      Cell(0, 0),
      Cell(1, 0),
      Cell(1, 1),
      Cell(1, 2),
    ],
  ],
];

// ============================================================
// TETROMINO
// ============================================================

class Tetromino {
  int type;
  int rotation;
  int x;
  int y;

  Tetromino({
    required this.type,
    this.rotation = 0,
    this.x = 3,
    this.y = 0,
  });

  Tetromino copy() {
    return Tetromino(
      type: type,
      rotation: rotation,
      x: x,
      y: y,
    );
  }

  List<Cell> get cells {
    return shapes[type][rotation]
        .map(
          (cell) => Cell(
        x + cell.x,
        y + cell.y,
      ),
    )
        .toList();
  }
}

// ============================================================
// HOME SCREEN
// ============================================================

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController controller;

  bool effects = true;
  bool haptics = true;

  @override
  void initState() {
    super.initState();

    controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  void play() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TetrisPage(
          effectsEnabled: effects,
          hapticsEnabled: haptics,
        ),
      ),
    );
  }

  void howToPlay() {
    showDialog(
      context: context,
      builder: (_) => const HowToPlayDialog(),
    );
  }

  void settings() {
    showDialog(
      context: context,
      builder: (_) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              backgroundColor: const Color(0xFF111625),
              title: const Text(
                'Settings',
                style: TextStyle(
                  fontWeight: FontWeight.w900,
                ),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SwitchListTile(
                    value: effects,
                    title: const Text('Visual Effects'),
                    onChanged: (value) {
                      setDialogState(() {
                        effects = value;
                      });

                      setState(() {});
                    },
                  ),
                  SwitchListTile(
                    value: haptics,
                    title: const Text('Haptic Feedback'),
                    onChanged: (value) {
                      setDialogState(() {
                        haptics = value;
                      });

                      setState(() {});
                    },
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnimatedBuilder(
        animation: controller,
        builder: (context, child) {
          return Stack(
            children: [
              Positioned.fill(
                child: CustomPaint(
                  painter: HomeBackground(
                    progress: controller.value,
                  ),
                ),
              ),
              SafeArea(
                child: Center(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(25),
                    child: Column(
                      children: [
                        const SizedBox(height: 35),

                        // LOGO
                        const Text(
                          'TETRIS',
                          style: TextStyle(
                            fontSize: 60,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 4,
                            color: Colors.white,
                            shadows: [
                              Shadow(
                                color: Color(0xFF35D9FF),
                                blurRadius: 25,
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 8),

                        const Text(
                          'CLASSIC BLOCK PUZZLE',
                          style: TextStyle(
                            color: Colors.white38,
                            fontSize: 11,
                            letterSpacing: 4,
                            fontWeight: FontWeight.w700,
                          ),
                        ),

                        const SizedBox(height: 50),

                        MenuButton(
                          icon: Icons.play_arrow_rounded,
                          text: 'PLAY',
                          primary: true,
                          onTap: play,
                        ),

                        const SizedBox(height: 12),

                        MenuButton(
                          icon: Icons.menu_book_rounded,
                          text: 'HOW TO PLAY',
                          onTap: howToPlay,
                        ),

                        const SizedBox(height: 12),

                        MenuButton(
                          icon: Icons.settings_rounded,
                          text: 'SETTINGS',
                          onTap: settings,
                        ),

                        const SizedBox(height: 50),

                        const Text(
                          'SMOOTH CONTROLS • HOLD • GHOST PIECE • COMBOS',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.white24,
                            fontSize: 9,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

// ============================================================
// HOME BACKGROUND
// ============================================================

class HomeBackground extends CustomPainter {
  final double progress;

  HomeBackground({
    required this.progress,
  });

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..color = const Color(0xFF03050D),
    );

    final glow = Paint()
      ..shader = RadialGradient(
        colors: const [
          Color(0x25356DFF),
          Color(0x00000000),
        ],
      ).createShader(
        Rect.fromCircle(
          center: Offset(
            size.width / 2,
            size.height * 0.3,
          ),
          radius: size.width * 0.75,
        ),
      );

    canvas.drawRect(
      Offset.zero & size,
      glow,
    );

    final random = math.Random(55);

    for (int i = 0; i < 80; i++) {
      final x = random.nextDouble() * size.width;
      final y = random.nextDouble() * size.height;

      final movement =
          math.sin(
            progress * math.pi * 2 + i,
          ) *
              7;

      canvas.drawCircle(
        Offset(x + movement, y),
        random.nextDouble() * 1.5,
        Paint()
          ..color = Colors.white.withOpacity(
            0.03 + random.nextDouble() * 0.07,
          ),
      );
    }
  }

  @override
  bool shouldRepaint(
      covariant HomeBackground oldDelegate,
      ) {
    return true;
  }
}

// ============================================================
// MENU BUTTON
// ============================================================

class MenuButton extends StatelessWidget {
  final IconData icon;
  final String text;
  final bool primary;
  final VoidCallback onTap;

  const MenuButton({
    super.key,
    required this.icon,
    required this.text,
    required this.onTap,
    this.primary = false,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 430,
      height: 62,
      child: Material(
        color: primary
            ? const Color(0xFF35D9FF)
            : const Color(0xFF101525),
        borderRadius: BorderRadius.circular(17),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(17),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                color: primary
                    ? Colors.black
                    : Colors.white,
              ),
              const SizedBox(width: 12),
              Text(
                text,
                style: TextStyle(
                  color: primary
                      ? Colors.black
                      : Colors.white,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// HOW TO PLAY
// ============================================================

class HowToPlayDialog extends StatelessWidget {
  const HowToPlayDialog({super.key});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: const Color(0xFF111625),
      title: const Text(
        'How To Play',
        style: TextStyle(
          fontWeight: FontWeight.w900,
        ),
      ),
      content: const Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          HelpRow(
            icon: Icons.swap_horiz,
            title: 'Move',
            text: 'A / D or Left / Right',
          ),
          HelpRow(
            icon: Icons.arrow_downward,
            title: 'Soft Drop',
            text: 'S or Down',
          ),
          HelpRow(
            icon: Icons.keyboard_double_arrow_down,
            title: 'Hard Drop',
            text: 'Space',
          ),
          HelpRow(
            icon: Icons.rotate_right,
            title: 'Rotate',
            text: 'W / Up / X',
          ),
          HelpRow(
            icon: Icons.rotate_left,
            title: 'Rotate Left',
            text: 'Z',
          ),
          HelpRow(
            icon: Icons.swap_horizontal_circle,
            title: 'Hold',
            text: 'C / Shift',
          ),
          HelpRow(
            icon: Icons.pause,
            title: 'Pause',
            text: 'P / Escape',
          ),
        ],
      ),
    );
  }
}

class HelpRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final String text;

  const HelpRow({
    super.key,
    required this.icon,
    required this.title,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        vertical: 6,
      ),
      child: Row(
        children: [
          Icon(
            icon,
            color: const Color(0xFF35D9FF),
            size: 20,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          Text(
            text,
            style: const TextStyle(
              color: Colors.white54,
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// GAME
// ============================================================

class TetrisPage extends StatefulWidget {
  final bool effectsEnabled;
  final bool hapticsEnabled;

  const TetrisPage({
    super.key,
    this.effectsEnabled = true,
    this.hapticsEnabled = true,
  });

  @override
  State<TetrisPage> createState() => _TetrisPageState();
}

class _TetrisPageState extends State<TetrisPage>
    with SingleTickerProviderStateMixin {
  late AnimationController gameTicker;

  final FocusNode focusNode = FocusNode();

  final math.Random random = math.Random();

  // BOARD
  List<List<int?>> board = [];

  Tetromino? current;
  Tetromino? holdPiece;

  List<int> nextQueue = [];

  // STATE
  bool paused = false;
  bool gameOver = false;
  bool canHold = true;

  // SCORE
  int score = 0;
  int bestScore = 0;
  int lines = 0;
  int level = 1;
  int combo = -1;

  // TIMERS
  double fallTimer = 0;
  double lockTimer = 0;

  double leftTimer = 0;
  double rightTimer = 0;

  double leftRepeatTimer = 0;
  double rightRepeatTimer = 0;

  bool leftHeld = false;
  bool rightHeld = false;
  bool downHeld = false;

  // EFFECTS
  final List<GameParticle> particles = [];
  final List<PopupText> popupTexts = [];

  double shake = 0;

  DateTime lastFrame = DateTime.now();

  @override
  void initState() {
    super.initState();

    resetGame();

    gameTicker = AnimationController(
      vsync: this,
      duration: const Duration(days: 1),
    )..addListener(gameLoop);

    gameTicker.repeat();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      focusNode.requestFocus();
    });
  }

  @override
  void dispose() {
    gameTicker.dispose();
    focusNode.dispose();
    super.dispose();
  }

  // ==========================================================
  // RESET
  // ==========================================================

  void resetGame() {
    board = List.generate(
      boardHeight,
          (_) => List<int?>.filled(
        boardWidth,
        null,
      ),
    );

    current = null;
    holdPiece = null;

    nextQueue = [];

    paused = false;
    gameOver = false;
    canHold = true;

    score = 0;
    lines = 0;
    level = 1;
    combo = -1;

    fallTimer = 0;
    lockTimer = 0;

    leftTimer = 0;
    rightTimer = 0;
    leftRepeatTimer = 0;
    rightRepeatTimer = 0;

    particles.clear();
    popupTexts.clear();

    shake = 0;

    fillQueue();
    spawnPiece();
  }

  // ==========================================================
  // LOOP
  // ==========================================================

  void gameLoop() {
    if (!mounted) return;

    final now = DateTime.now();

    double dt =
        now.difference(lastFrame).inMicroseconds /
            1000000.0;

    lastFrame = now;

    dt = dt.clamp(0.0, 0.05);

    setState(() {
      updateGame(dt);
    });
  }

  void updateGame(double dt) {
    updateParticles(dt);
    updatePopups(dt);

    if (shake > 0) {
      shake -= dt * 18;

      if (shake < 0) {
        shake = 0;
      }
    }

    if (paused || gameOver) {
      return;
    }

    updateHorizontalInput(dt);

    // GRAVITY
    fallTimer += dt;

    final interval =
    downHeld
        ? 0.035
        : gravitySpeed();

    if (fallTimer >= interval) {
      fallTimer = 0;

      final moved = movePiece(
        0,
        1,
      );

      if (moved) {
        lockTimer = 0;
      }
    }

    // LOCK DELAY
    if (isGrounded()) {
      lockTimer += dt;

      if (lockTimer >= 0.45) {
        lockPiece();
      }
    } else {
      lockTimer = 0;
    }
  }

  double gravitySpeed() {
    const speeds = [
      0.80,
      0.72,
      0.63,
      0.55,
      0.47,
      0.39,
      0.32,
      0.26,
      0.21,
      0.17,
      0.14,
      0.115,
      0.095,
      0.080,
      0.068,
      0.058,
      0.050,
      0.043,
      0.037,
      0.032,
    ];

    return speeds[
    math.min(
      level - 1,
      speeds.length - 1,
    )];
  }

  // ==========================================================
  // QUEUE
  // ==========================================================

  void fillQueue() {
    while (nextQueue.length < 7) {
      final bag = List.generate(
        7,
            (index) => index,
      );

      bag.shuffle(random);

      nextQueue.addAll(bag);
    }
  }

  void spawnPiece() {
    fillQueue();

    current = Tetromino(
      type: nextQueue.removeAt(0),
      x: 3,
      y: 0,
    );

    fillQueue();

    canHold = true;

    fallTimer = 0;
    lockTimer = 0;

    if (collides(current!)) {
      gameOver = true;
    }
  }

  // ==========================================================
  // COLLISION
  // ==========================================================

  bool collides(Tetromino piece) {
    for (final cell in piece.cells) {
      if (cell.x < 0 ||
          cell.x >= boardWidth ||
          cell.y >= boardHeight) {
        return true;
      }

      if (cell.y >= 0 &&
          board[cell.y][cell.x] != null) {
        return true;
      }
    }

    return false;
  }

  bool isGrounded() {
    if (current == null) {
      return false;
    }

    final test = current!.copy();

    test.y++;

    return collides(test);
  }

  // ==========================================================
  // MOVE
  // ==========================================================

  bool movePiece(
      int dx,
      int dy,
      ) {
    if (current == null ||
        paused ||
        gameOver) {
      return false;
    }

    final test = current!.copy();

    test.x += dx;
    test.y += dy;

    if (!collides(test)) {
      current = test;

      if (isGrounded()) {
        lockTimer = 0;
      }

      return true;
    }

    return false;
  }

  // ==========================================================
  // ROTATE
  // ==========================================================

  void rotate(int direction) {
    if (current == null ||
        paused ||
        gameOver) {
      return;
    }

    if (current!.type == 1) {
      return;
    }

    final original = current!.copy();

    int next =
        current!.rotation + direction;

    if (next < 0) {
      next = 3;
    }

    if (next > 3) {
      next = 0;
    }

    current!.rotation = next;

    final kicks = [
      const Cell(0, 0),
      const Cell(-1, 0),
      const Cell(1, 0),
      const Cell(0, -1),
      const Cell(0, 1),
      const Cell(-2, 0),
      const Cell(2, 0),
    ];

    for (final kick in kicks) {
      final test = current!.copy();

      test.x += kick.x;
      test.y += kick.y;

      if (!collides(test)) {
        current = test;
        lockTimer = 0;
        haptic();
        return;
      }
    }

    current = original;
  }

  // ==========================================================
  // HARD DROP
  // ==========================================================

  void hardDrop() {
    if (current == null ||
        paused ||
        gameOver) {
      return;
    }

    int distance = 0;

    while (true) {
      final moved = movePiece(
        0,
        1,
      );

      if (!moved) {
        break;
      }

      distance++;
    }

    score += distance * 2;

    updateBest();

    if (widget.effectsEnabled) {
      shake = distance > 8 ? 6 : 2;

      for (final cell in current!.cells) {
        spawnParticles(
          cell.x + 0.5,
          cell.y + 0.5,
          pieceColors[current!.type],
          4,
        );
      }
    }

    haptic();

    lockPiece();
  }

  // ==========================================================
  // HOLD
  // ==========================================================

  void hold() {
    if (current == null ||
        !canHold ||
        paused ||
        gameOver) {
      return;
    }

    final currentType = current!.type;

    if (holdPiece == null) {
      holdPiece = Tetromino(
        type: currentType,
      );

      spawnPiece();
    } else {
      final heldType = holdPiece!.type;

      holdPiece = Tetromino(
        type: currentType,
      );

      current = Tetromino(
        type: heldType,
        x: 3,
        y: 0,
      );
    }

    current!.rotation = 0;

    canHold = false;

    fallTimer = 0;
    lockTimer = 0;

    haptic();
  }

  // ==========================================================
  // LOCK
  // ==========================================================

  void lockPiece() {
    if (current == null) {
      return;
    }

    final type = current!.type;

    for (final cell in current!.cells) {
      if (cell.x >= 0 &&
          cell.x < boardWidth &&
          cell.y >= 0 &&
          cell.y < boardHeight) {
        board[cell.y][cell.x] = type;
      }
    }

    if (widget.effectsEnabled) {
      for (final cell in current!.cells) {
        spawnParticles(
          cell.x + 0.5,
          cell.y + 0.5,
          pieceColors[type],
          2,
        );
      }
    }

    final fullRows = <int>[];

    for (int y = 0; y < boardHeight; y++) {
      bool full = true;

      for (int x = 0; x < boardWidth; x++) {
        if (board[y][x] == null) {
          full = false;
          break;
        }
      }

      if (full) {
        fullRows.add(y);
      }
    }

    if (fullRows.isNotEmpty) {
      clearRows(fullRows);
    } else {
      combo = -1;
      spawnPiece();
    }
  }

  // ==========================================================
  // CLEAR ROWS
  // ==========================================================

  void clearRows(
      List<int> rows,
      ) {
    final amount = rows.length;

    for (final row in rows.reversed) {
      board.removeAt(row);
    }

    while (board.length < boardHeight) {
      board.insert(
        0,
        List<int?>.filled(
          boardWidth,
          null,
        ),
      );
    }

    combo++;

    int base;

    switch (amount) {
      case 1:
        base = 100;
        break;
      case 2:
        base = 300;
        break;
      case 3:
        base = 500;
        break;
      case 4:
        base = 800;
        break;
      default:
        base = 0;
    }

    score += base * level;

    if (combo > 0) {
      score += combo * 50 * level;
    }

    lines += amount;

    level =
        (lines ~/ 10) + 1;

    updateBest();

    if (widget.effectsEnabled) {
      shake =
      amount == 4
          ? 7
          : 3;

      if (amount == 4) {
        popupTexts.add(
          PopupText(
            text: 'TETRIS!',
            x: boardWidth / 2,
            y: 8,
            color: const Color(0xFFFFD83D),
          ),
        );
      } else if (amount == 3) {
        popupTexts.add(
          PopupText(
            text: 'TRIPLE!',
            x: boardWidth / 2,
            y: 8,
            color: const Color(0xFF35D9FF),
          ),
        );
      } else if (amount == 2) {
        popupTexts.add(
          PopupText(
            text: 'DOUBLE!',
            x: boardWidth / 2,
            y: 8,
            color: const Color(0xFF35D9FF),
          ),
        );
      } else {
        popupTexts.add(
          PopupText(
            text: 'LINE CLEAR!',
            x: boardWidth / 2,
            y: 8,
            color: const Color(0xFF35D9FF),
          ),
        );
      }

      if (combo > 0) {
        popupTexts.add(
          PopupText(
            text: 'COMBO x$combo',
            x: boardWidth / 2,
            y: 10,
            color: const Color(0xFFFFA43D),
          ),
        );
      }
    }

    haptic();

    spawnPiece();
  }

  // ==========================================================
  // GHOST
  // ==========================================================

  Tetromino? ghostPiece() {
    if (current == null) {
      return null;
    }

    final ghost = current!.copy();

    while (true) {
      final test = ghost.copy();

      test.y++;

      if (collides(test)) {
        break;
      }

      ghost.y++;
    }

    return ghost;
  }

  // ==========================================================
  // INPUT
  // ==========================================================

  KeyEventResult keyboard(
      FocusNode node,
      KeyEvent event,
      ) {
    if (event is KeyDownEvent) {
      final key = event.logicalKey;

      if (key == LogicalKeyboardKey.escape ||
          key == LogicalKeyboardKey.keyP) {
        togglePause();
        return KeyEventResult.handled;
      }

      if (gameOver) {
        if (key == LogicalKeyboardKey.enter) {
          restart();
        }

        return KeyEventResult.handled;
      }

      if (paused) {
        return KeyEventResult.handled;
      }

      if (key == LogicalKeyboardKey.arrowLeft ||
          key == LogicalKeyboardKey.keyA) {
        if (!leftHeld) {
          leftHeld = true;
          leftTimer = 0;
          leftRepeatTimer = 0;
          movePiece(-1, 0);
        }

        return KeyEventResult.handled;
      }

      if (key == LogicalKeyboardKey.arrowRight ||
          key == LogicalKeyboardKey.keyD) {
        if (!rightHeld) {
          rightHeld = true;
          rightTimer = 0;
          rightRepeatTimer = 0;
          movePiece(1, 0);
        }

        return KeyEventResult.handled;
      }

      if (key == LogicalKeyboardKey.arrowDown ||
          key == LogicalKeyboardKey.keyS) {
        downHeld = true;
        return KeyEventResult.handled;
      }

      if (key == LogicalKeyboardKey.arrowUp ||
          key == LogicalKeyboardKey.keyW ||
          key == LogicalKeyboardKey.keyX) {
        rotate(1);
        return KeyEventResult.handled;
      }

      if (key == LogicalKeyboardKey.keyZ) {
        rotate(-1);
        return KeyEventResult.handled;
      }

      if (key == LogicalKeyboardKey.space) {
        hardDrop();
        return KeyEventResult.handled;
      }

      if (key == LogicalKeyboardKey.keyC ||
          key == LogicalKeyboardKey.shiftLeft ||
          key == LogicalKeyboardKey.shiftRight) {
        hold();
        return KeyEventResult.handled;
      }
    }

    if (event is KeyUpEvent) {
      final key = event.logicalKey;

      if (key == LogicalKeyboardKey.arrowLeft ||
          key == LogicalKeyboardKey.keyA) {
        leftHeld = false;
        leftTimer = 0;
        leftRepeatTimer = 0;
      }

      if (key == LogicalKeyboardKey.arrowRight ||
          key == LogicalKeyboardKey.keyD) {
        rightHeld = false;
        rightTimer = 0;
        rightRepeatTimer = 0;
      }

      if (key == LogicalKeyboardKey.arrowDown ||
          key == LogicalKeyboardKey.keyS) {
        downHeld = false;
      }

      return KeyEventResult.handled;
    }

    return KeyEventResult.ignored;
  }

  void updateHorizontalInput(
      double dt,
      ) {
    if (leftHeld) {
      leftTimer += dt;

      if (leftTimer >= 0.13) {
        leftRepeatTimer += dt;

        if (leftRepeatTimer >= 0.035) {
          leftRepeatTimer = 0;
          movePiece(-1, 0);
        }
      }
    }

    if (rightHeld) {
      rightTimer += dt;

      if (rightTimer >= 0.13) {
        rightRepeatTimer += dt;

        if (rightRepeatTimer >= 0.035) {
          rightRepeatTimer = 0;
          movePiece(1, 0);
        }
      }
    }
  }

  // ==========================================================
  // MOBILE
  // ==========================================================

  void mobileLeft() {
    movePiece(-1, 0);
  }

  void mobileRight() {
    movePiece(1, 0);
  }

  void mobileDown() {
    if (movePiece(0, 1)) {
      score++;
      updateBest();
    }
  }

  // ==========================================================
  // PAUSE
  // ==========================================================

  void togglePause() {
    if (gameOver) {
      return;
    }

    setState(() {
      paused = !paused;
    });

    haptic();
  }

  void restart() {
    setState(() {
      resetGame();
    });

    focusNode.requestFocus();
  }

  void home() {
    Navigator.pop(context);
  }

  // ==========================================================
  // EFFECTS
  // ==========================================================

  void spawnParticles(
      double x,
      double y,
      Color color,
      int count,
      ) {
    if (!widget.effectsEnabled) {
      return;
    }

    for (int i = 0; i < count; i++) {
      final angle =
          random.nextDouble() *
              math.pi *
              2;

      final speed =
          0.3 +
              random.nextDouble() * 1.8;

      particles.add(
        GameParticle(
          x: x,
          y: y,
          vx: math.cos(angle) * speed,
          vy: math.sin(angle) * speed,
          life:
          0.25 +
              random.nextDouble() * 0.45,
          color: color,
        ),
      );
    }

    if (particles.length > 500) {
      particles.removeRange(
        0,
        particles.length - 500,
      );
    }
  }

  void updateParticles(double dt) {
    for (final particle in particles) {
      particle.update(dt);
    }

    particles.removeWhere(
          (particle) => particle.life <= 0,
    );
  }

  void updatePopups(double dt) {
    for (final popup in popupTexts) {
      popup.update(dt);
    }

    popupTexts.removeWhere(
          (popup) => popup.life <= 0,
    );
  }

  void updateBest() {
    if (score > bestScore) {
      bestScore = score;
    }
  }

  void haptic() {
    if (widget.hapticsEnabled) {
      HapticFeedback.lightImpact();
    }

    SystemSound.play(
      SystemSoundType.click,
    );
  }

  // ==========================================================
  // BUILD
  // ==========================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF03050D),
      body: Focus(
        focusNode: focusNode,
        autofocus: true,
        onKeyEvent: keyboard,
        child: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              if (constraints.maxWidth < 800) {
                return mobileLayout(
                  constraints,
                );
              }

              return desktopLayout(
                constraints,
              );
            },
          ),
        ),
      ),
    );
  }

  // ==========================================================
  // DESKTOP
  // ==========================================================

  Widget desktopLayout(
      BoxConstraints constraints,
      ) {
    return Row(
      children: [
        Expanded(
          child: Center(
            child: buildBoard(
              width: math.min(
                540,
                constraints.maxHeight *
                    0.5,
              ),
            ),
          ),
        ),
        SizedBox(
          width: 280,
          child: desktopPanel(),
        ),
      ],
    );
  }

  // ==========================================================
  // MOBILE
  // ==========================================================

  Widget mobileLayout(
      BoxConstraints constraints,
      ) {
    return Column(
      children: [
        mobileHeader(),

        Expanded(
          child: Center(
            child: buildBoard(
              width: math.min(
                constraints.maxWidth - 16,
                (constraints.maxHeight - 150) *
                    0.5,
              ),
            ),
          ),
        ),

        mobileControls(),

        const SizedBox(height: 8),
      ],
    );
  }

  // ==========================================================
  // BOARD
  // ==========================================================

  Widget buildBoard({
    required double width,
  }) {
    final height =
        width * 2;

    final ghost = ghostPiece();

    return Transform.translate(
      offset: Offset(
        shake == 0
            ? 0
            : (random.nextDouble() - 0.5) *
            shake,
        shake == 0
            ? 0
            : (random.nextDouble() - 0.5) *
            shake,
      ),
      child: SizedBox(
        width: width,
        height: height,
        child: ClipRRect(
          borderRadius:
          BorderRadius.circular(18),
          child: Container(
            decoration: BoxDecoration(
              color: const Color(0xFF080B18),
              border: Border.all(
                color: Colors.white.withOpacity(
                  0.12,
                ),
                width: 1.5,
              ),
              borderRadius:
              BorderRadius.circular(18),
            ),
            child: Stack(
              children: [
                // GRID
                Positioned.fill(
                  child: GridLines(
                    width: width,
                    height: height,
                  ),
                ),

                // LOCKED BLOCKS
                for (int y = 0;
                y < boardHeight;
                y++)
                  for (int x = 0;
                  x < boardWidth;
                  x++)
                    if (board[y][x] != null)
                      Positioned(
                        left:
                        x * width / boardWidth,
                        top:
                        y * height / boardHeight,
                        width:
                        width / boardWidth,
                        height:
                        height / boardHeight,
                        child: TetrisBlock(
                          color:
                          pieceColors[
                          board[y][x]!],
                        ),
                      ),

                // GHOST
                if (ghost != null)
                  for (final cell
                  in ghost.cells)
                    if (cell.x >= 0 &&
                        cell.x < boardWidth &&
                        cell.y >= 0 &&
                        cell.y < boardHeight)
                      Positioned(
                        left:
                        cell.x *
                            width /
                            boardWidth,
                        top:
                        cell.y *
                            height /
                            boardHeight,
                        width:
                        width /
                            boardWidth,
                        height:
                        height /
                            boardHeight,
                        child: GhostBlock(
                          color:
                          pieceColors[
                          ghost.type],
                        ),
                      ),

                // CURRENT PIECE
                if (current != null)
                  for (final cell
                  in current!.cells)
                    if (cell.x >= 0 &&
                        cell.x < boardWidth &&
                        cell.y >= 0 &&
                        cell.y < boardHeight)
                      Positioned(
                        left:
                        cell.x *
                            width /
                            boardWidth,
                        top:
                        cell.y *
                            height /
                            boardHeight,
                        width:
                        width /
                            boardWidth,
                        height:
                        height /
                            boardHeight,
                        child: TetrisBlock(
                          color:
                          pieceColors[
                          current!.type],
                        ),
                      ),

                // PARTICLES
                for (final particle
                in particles)
                  Positioned(
                    left:
                    particle.x *
                        width /
                        boardWidth,
                    top:
                    particle.y *
                        height /
                        boardHeight,
                    child: IgnorePointer(
                      child: Container(
                        width: 4,
                        height: 4,
                        decoration:
                        BoxDecoration(
                          shape:
                          BoxShape.circle,
                          color:
                          particle.color
                              .withOpacity(
                            particle.opacity,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color:
                              particle.color
                                  .withOpacity(
                                particle.opacity *
                                    0.5,
                              ),
                              blurRadius: 7,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                // POPUP TEXT
                for (final popup
                in popupTexts)
                  Positioned(
                    left:
                    popup.x *
                        width /
                        boardWidth -
                        70,
                    top:
                    popup.y *
                        height /
                        boardHeight,
                    width: 140,
                    child: IgnorePointer(
                      child: Opacity(
                        opacity: popup.opacity,
                        child: Text(
                          popup.text,
                          textAlign:
                          TextAlign.center,
                          style: TextStyle(
                            color: popup.color,
                            fontSize:
                            math.max(
                              14,
                              width * 0.045,
                            ),
                            fontWeight:
                            FontWeight.w900,
                            shadows: [
                              Shadow(
                                color:
                                popup.color
                                    .withOpacity(
                                  0.7,
                                ),
                                blurRadius: 12,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),

                // PAUSE OVERLAY
                if (paused)
                  Positioned.fill(
                    child: GameOverlay(
                      title: 'PAUSED',
                      subtitle:
                      'Press P or tap play to continue',
                      buttonText: 'RESUME',
                      icon:
                      Icons.play_arrow_rounded,
                      onPressed:
                      togglePause,
                    ),
                  ),

                // GAME OVER
                if (gameOver)
                  Positioned.fill(
                    child: GameOverlay(
                      title: 'GAME OVER',
                      subtitle:
                      'Score: $score',
                      buttonText: 'RESTART',
                      icon:
                      Icons.refresh_rounded,
                      onPressed:
                      restart,
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ==========================================================
  // DESKTOP PANEL
  // ==========================================================

  Widget desktopPanel() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        8,
        25,
        25,
        25,
      ),
      child: Column(
        children: [
          const Text(
            'NEON TETRIS',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w900,
              letterSpacing: 2,
            ),
          ),

          const SizedBox(height: 20),

          infoCard(
            'HOLD',
            holdPiece == null
                ? const Text(
              'EMPTY',
              style: TextStyle(
                color: Colors.white24,
                fontWeight:
                FontWeight.w900,
              ),
            )
                : SizedBox(
              height: 80,
              child: MiniPiece(
                type:
                holdPiece!.type,
              ),
            ),
          ),

          const SizedBox(height: 12),

          infoCard(
            'STATS',
            Column(
              children: [
                stat(
                  'SCORE',
                  '$score',
                ),
                stat(
                  'BEST',
                  '$bestScore',
                ),
                stat(
                  'LINES',
                  '$lines',
                ),
                stat(
                  'LEVEL',
                  '$level',
                ),
                if (combo > 0)
                  stat(
                    'COMBO',
                    'x$combo',
                  ),
              ],
            ),
          ),

          const SizedBox(height: 12),

          infoCard(
            'NEXT',
            Column(
              children: [
                for (
                int i = 0;
                i <
                    math.min(
                      3,
                      nextQueue.length,
                    );
                i++
                )
                  SizedBox(
                    height: 55,
                    child: MiniPiece(
                      type:
                      nextQueue[i],
                    ),
                  ),
              ],
            ),
          ),

          const Spacer(),

          Row(
            children: [
              Expanded(
                child: SmallButton(
                  icon:
                  Icons.pause_rounded,
                  text: 'PAUSE',
                  onTap: togglePause,
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: SmallButton(
                  icon:
                  Icons.refresh_rounded,
                  text: 'RESET',
                  onTap: restart,
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: SmallButton(
                  icon:
                  Icons.home_rounded,
                  text: 'HOME',
                  onTap: home,
                ),
              ),
            ],
          ),

          const SizedBox(height: 15),

          const Text(
            'A / D     MOVE\n'
                'W / X     ROTATE\n'
                'SPACE     HARD DROP\n'
                'C / SHIFT HOLD\n'
                'P / ESC   PAUSE',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white24,
              fontSize: 9,
              height: 1.8,
            ),
          ),
        ],
      ),
    );
  }

  Widget infoCard(
      String title,
      Widget child,
      ) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0D1120),
        borderRadius:
        BorderRadius.circular(16),
        border: Border.all(
          color:
          Colors.white.withOpacity(0.06),
        ),
      ),
      child: Column(
        crossAxisAlignment:
        CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Colors.white38,
              fontSize: 10,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 8),
          child,
        ],
      ),
    );
  }

  Widget stat(
      String title,
      String value,
      ) {
    return Padding(
      padding:
      const EdgeInsets.symmetric(
        vertical: 4,
      ),
      child: Row(
        mainAxisAlignment:
        MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Colors.white38,
              fontSize: 10,
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // MOBILE HEADER
  // ==========================================================

  Widget mobileHeader() {
    return SizedBox(
      height: 55,
      child: Row(
        children: [
          IconButton(
            onPressed: home,
            icon: const Icon(
              Icons.home_rounded,
            ),
          ),
          Expanded(
            child: Column(
              mainAxisAlignment:
              MainAxisAlignment.center,
              children: [
                const Text(
                  'TETRIS',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                  ),
                ),
                Text(
                  'SCORE $score  •  LEVEL $level',
                  style: const TextStyle(
                    color: Colors.white38,
                    fontSize: 9,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: togglePause,
            icon: Icon(
              paused
                  ? Icons.play_arrow_rounded
                  : Icons.pause_rounded,
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // MOBILE CONTROLS
  // ==========================================================

  Widget mobileControls() {
    return Padding(
      padding:
      const EdgeInsets.symmetric(
        horizontal: 8,
      ),
      child: Row(
        children: [
          controlButton(
            Icons.arrow_left_rounded,
            mobileLeft,
          ),
          controlButton(
            Icons.arrow_right_rounded,
            mobileRight,
          ),
          controlButton(
            Icons.arrow_downward_rounded,
            mobileDown,
          ),
          controlButton(
            Icons.rotate_right_rounded,
                () => rotate(1),
          ),
          controlButton(
            Icons.keyboard_double_arrow_down_rounded,
            hardDrop,
          ),
          controlButton(
            Icons.swap_horiz_rounded,
            hold,
          ),
        ],
      ),
    );
  }

  Widget controlButton(
      IconData icon,
      VoidCallback action,
      ) {
    return Expanded(
      child: Padding(
        padding:
        const EdgeInsets.symmetric(
          horizontal: 3,
        ),
        child: SizedBox(
          height: 50,
          child: Material(
            color: const Color(0xFF111625),
            borderRadius:
            BorderRadius.circular(13),
            child: InkWell(
              onTap: action,
              borderRadius:
              BorderRadius.circular(13),
              child: Icon(
                icon,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// ACTUAL BLOCK WIDGET
// ============================================================

class TetrisBlock extends StatelessWidget {
  final Color color;

  const TetrisBlock({
    super.key,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(1.5),
      child: Container(
        decoration: BoxDecoration(
          color: color,
          borderRadius:
          BorderRadius.circular(4),
          boxShadow: [
            BoxShadow(
              color:
              color.withOpacity(0.35),
              blurRadius: 7,
              spreadRadius: 0.5,
            ),
          ],
        ),
        child: Stack(
          children: [
            // TOP HIGHLIGHT
            Positioned(
              left: 3,
              right: 3,
              top: 3,
              child: Container(
                height: 3,
                decoration: BoxDecoration(
                  color: Colors.white
                      .withOpacity(0.42),
                  borderRadius:
                  BorderRadius.circular(4),
                ),
              ),
            ),

            // LEFT HIGHLIGHT
            Positioned(
              left: 3,
              top: 5,
              bottom: 5,
              child: Container(
                width: 2,
                decoration: BoxDecoration(
                  color: Colors.white
                      .withOpacity(0.20),
                  borderRadius:
                  BorderRadius.circular(4),
                ),
              ),
            ),

            // BOTTOM SHADOW
            Positioned(
              left: 4,
              right: 4,
              bottom: 3,
              child: Container(
                height: 3,
                decoration: BoxDecoration(
                  color: Colors.black
                      .withOpacity(0.20),
                  borderRadius:
                  BorderRadius.circular(4),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// GHOST BLOCK
// ============================================================

class GhostBlock extends StatelessWidget {
  final Color color;

  const GhostBlock({
    super.key,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(3),
      child: Container(
        decoration: BoxDecoration(
          color:
          color.withOpacity(0.045),
          borderRadius:
          BorderRadius.circular(4),
          border: Border.all(
            color:
            color.withOpacity(0.35),
            width: 1,
          ),
        ),
      ),
    );
  }
}

// ============================================================
// GRID
// ============================================================

class GridLines extends StatelessWidget {
  final double width;
  final double height;

  const GridLines({
    super.key,
    required this.width,
    required this.height,
  });

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: GridPainter(),
    );
  }
}

class GridPainter extends CustomPainter {
  @override
  void paint(
      Canvas canvas,
      Size size,
      ) {
    final paint = Paint()
      ..color =
      Colors.white.withOpacity(0.035)
      ..strokeWidth = 0.7;

    final cellWidth =
        size.width / boardWidth;

    final cellHeight =
        size.height / boardHeight;

    for (int x = 0;
    x <= boardWidth;
    x++) {
      canvas.drawLine(
        Offset(
          x * cellWidth,
          0,
        ),
        Offset(
          x * cellWidth,
          size.height,
        ),
        paint,
      );
    }

    for (int y = 0;
    y <= boardHeight;
    y++) {
      canvas.drawLine(
        Offset(
          0,
          y * cellHeight,
        ),
        Offset(
          size.width,
          y * cellHeight,
        ),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(
      covariant GridPainter oldDelegate,
      ) {
    return false;
  }
}

// ============================================================
// MINI PIECE
// ============================================================

class MiniPiece extends StatelessWidget {
  final int type;

  const MiniPiece({
    super.key,
    required this.type,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SizedBox(
        width: 90,
        height: 45,
        child: Stack(
          children: [
            for (final cell in shapes[type][0])
              Positioned(
                left:
                20 +
                    cell.x * 18.0,
                top:
                2 +
                    cell.y * 18.0,
                width: 17,
                height: 17,
                child: TetrisBlock(
                  color:
                  pieceColors[type],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// GAME OVER / PAUSE
// ============================================================

class GameOverlay extends StatelessWidget {
  final String title;
  final String subtitle;
  final String buttonText;
  final IconData icon;
  final VoidCallback onPressed;

  const GameOverlay({
    super.key,
    required this.title,
    required this.subtitle,
    required this.buttonText,
    required this.icon,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color:
      Colors.black.withOpacity(0.68),
      child: Center(
        child: Container(
          margin:
          const EdgeInsets.all(30),
          padding:
          const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: const Color(0xFF101525),
            borderRadius:
            BorderRadius.circular(22),
            border: Border.all(
              color:
              Colors.white.withOpacity(0.08),
            ),
          ),
          child: Column(
            mainAxisSize:
            MainAxisSize.min,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 27,
                  fontWeight:
                  FontWeight.w900,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                subtitle,
                style: const TextStyle(
                  color: Colors.white54,
                ),
              ),
              const SizedBox(height: 22),
              SizedBox(
                width: 180,
                height: 48,
                child: ElevatedButton.icon(
                  onPressed: onPressed,
                  icon: Icon(icon),
                  label: Text(buttonText),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// SMALL BUTTON
// ============================================================

class SmallButton extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;

  const SmallButton({
    super.key,
    required this.icon,
    required this.text,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xFF111625),
      borderRadius:
      BorderRadius.circular(12),
      child: InkWell(
        onTap: onTap,
        borderRadius:
        BorderRadius.circular(12),
        child: Padding(
          padding:
          const EdgeInsets.symmetric(
            vertical: 9,
          ),
          child: Column(
            children: [
              Icon(
                icon,
                size: 17,
                color: Colors.white70,
              ),
              const SizedBox(height: 3),
              Text(
                text,
                style: const TextStyle(
                  color: Colors.white38,
                  fontSize: 7,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// PARTICLES
// ============================================================

class GameParticle {
  double x;
  double y;
  double vx;
  double vy;
  double life;
  final Color color;

  GameParticle({
    required this.x,
    required this.y,
    required this.vx,
    required this.vy,
    required this.life,
    required this.color,
  });

  void update(double dt) {
    x += vx * dt;
    y += vy * dt;

    vy += 2 * dt;

    vx *= 0.98;
  }

  double get opacity {
    return life.clamp(0.0, 1.0);
  }
}

// ============================================================
// POPUP
// ============================================================

class PopupText {
  final String text;
  final double x;
  double y;
  final Color color;

  double life = 1;

  PopupText({
    required this.text,
    required this.x,
    required this.y,
    required this.color,
  });

  void update(double dt) {
    y -= dt * 1.3;
    life -= dt;
  }

  double get opacity {
    return life.clamp(0.0, 1.0);
  }
}